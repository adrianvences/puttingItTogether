
// this is mapping out an array which can be exported and used as data to dry (dont repeat yourself)code

const people =[
  {
  firstName: 'Jane',
  lastName : 'Doe',
  age : 18 ,
  hairColor : 'Black'
  } ,
  {
  firstName: 'John',
  lastName : 'Smith',
  age : 88 ,
  hairColor : 'Brown'
  } ,
  {
  firstName: 'Millard',
  lastName : 'Fillmore',
  age : 50 ,
  hairColor : 'Brown'
  } ,
  {
  firstName: 'Jane',
  lastName : 'Doe',
  age : 62 ,
  hairColor : 'Brown'
  } ,
  
]

export default people;